<?php

	define('DS',DIRECTORY_SEPARATOR);

	define('ROOT',$_SERVER['DOCUMENT_ROOT']);

	define('APP','admin'.DS.'App');

	define('CTRL',ROOT.DS.APP.DS.'Control'.DS);

	define('SMARTY',ROOT.DS.'Core'.DS.'libs'.DS);

	$config = include(ROOT.DS.'Core/Config/config.php');

	$db = include(ROOT.DS.'Core/Model/db.php');

	$template = include(ROOT.DS.'Core/View/template.php');

	$view = $template->smarty();
	
	$ctrl = include(ROOT.DS.'Core/Control/Control.php');

	$ini = include(ROOT.DS.'Core/Config/ini.php');

	$ini->run();