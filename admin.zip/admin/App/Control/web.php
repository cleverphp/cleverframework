<?php
	
	class web extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){

			$web = $this->db->query("select config from web where id = 1");

			if(!is_null($web[0]['config'])):

				$this->view->assign('web',unserialize($web[0]['config']));
			else:
				$this->view->assign('web',array());
			endif;

			$this->view->display('web.tpl');
		
		}

		public function update(){

			$item = $_GET['item'];

			$val = $_GET['val'];

			$web = $this->db->query("select config from web where id = 1");

			if(!is_null($web[0]['config'])):

				$arr = unserialize($web[0]['config']);
				$arr[$item] = $val;
				$str = serialize($arr);
				$this->db->execute("update web set config = '$str' where id = 1");
			else:

				$str = serialize(array($item=>$val));

				$this->db->execute("update web set config = '$str' where id = 1");

			endif;

			echo "success";

		}

		public function uploadIco(){

			$file = $_FILES['ico'];

			if($file['type'] != 'image/x-icon'){

				echo 'err';exit;

			}

			if($file['size'] > 100*1024){

				echo 'err';exit;
			}

			$name = time().strrchr($file['name'],'.');

			move_uploaded_file($file['tmp_name'],$_SERVER['DOCUMENT_ROOT'].DS.'data'.DS.'logo'.DS.$name);

			$ico_url = '/data/logo/'.$name;

			$item = 'ico';

			$val = $ico_url;

			$web = $this->db->query("select config from web where id = 1");

			if(!is_null($web[0]['config'])):

				$arr = unserialize($web[0]['config']);
				$arr[$item] = $val;
				$str = serialize($arr);
				$this->db->execute("update web set config = '$str' where id = 1");
			else:

				$str = serialize(array($item=>$val));

				$this->db->execute("update web set config = '$str' where id = 1");

			endif;

			echo 'ok';

		}

	}

	return new web;

?>