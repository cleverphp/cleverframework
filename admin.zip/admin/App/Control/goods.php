<?php
	
	class goods extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){

			$this->view->assign('hello','hello world');
			
			/**
			$sql = "select * from hello";

			$res = $this->db->query($sql);

			$this->view->assign('res',$res);

			**/


			$this->view->display('goods.tpl');
		
		}

	}

	return new goods;

?>