<?php
	
	class lunbo extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){

			$res = $this->db->query("select config from web where id = 2");

			$maxImage = array(0,1,2,3,4,5,6,7,8,9);

			$this->view->assign('maxImage',$maxImage);

			if($res[0]['config']){

				$arr = unserialize($res[0]['config']);
				$this->view->assign('lunbo',$arr);
			}

			$this->view->display('lunbo.tpl');
		
		}

		public function ajax_upload(){

			$files = array();

			for($i=0;$i<=9;$i++){

				if(isset($_FILES['file'.$i])){
					array_push($files,$_FILES['file'.$i]);
				}
			}

			foreach($files as $v){

				if(!in_array($v['type'],array('image/jpeg','image/png','image/gif')) || $v['size'] > 4*1024*1024):
					exit('error');
				endif;

			}

			$name = time();

			$url = [];

			foreach($files as $k=>$v){

				$tmp  = $name.'_'.$k;

				$ext = strrchr($v['name'],'.');

				$tmp .= $ext;

				move_uploaded_file($v['tmp_name'],$_SERVER['DOCUMENT_ROOT'].DS.'data'.DS.'images'.DS.$tmp);

				$url[] = '/data/images/'.$tmp;

			}

			echo json_encode($url);

		}

		public function save_upload(){

			$images = serialize(explode(',',$_POST['images']));

			$sql = "update web set config = '$images' where id = 2";

			$this->db->execute($sql);

			echo "success";

		}



	}

	return new lunbo;

?>