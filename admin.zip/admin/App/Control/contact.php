<?php
	
	class contact extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){

			$res = $this->db->query("select * from web where id = 1");

			$see = '';

			$tmp = unserialize($res[0]['config']);

			if($tmp['receiver']){

				$see = $tmp['receiver'];

			}

			$this->view->assign('see',$see);

			$this->view->display('contact.tpl');
		
		}

	}

	return new contact;

?>