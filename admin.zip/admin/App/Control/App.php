<?php
	
	class App extends Control{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();

			$this->setCom();
		
		}

		public function setCom(){

			$loginUrl = 'http://'.$_SERVER['SERVER_NAME'].'/admin/index.php?c=login';

			if(!isset($_SESSION['login']) || $_SESSION['login'] != 1):

				header("location:$loginUrl");
				exit;

			endif;

			$this->view->assign('assets','/admin/App/Public');

		}

		

	}

?>