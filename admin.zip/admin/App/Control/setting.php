<?php
	
	class setting extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){
			
			$this->view->display('setting.tpl');
		
		}

	}

	return new setting;

?>