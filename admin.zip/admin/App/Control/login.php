<?php
	
	//login is different with other files,as directly extends from Ctrl
	class login extends Control{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();

			$this->view->assign('assets','/'.APP.'/Public');
		
		}

		public function index(){

			$jumpUrl = 'http://'.$_SERVER['SERVER_NAME'].'/admin/index.php';

			if(isset($_SESSION['login']) && $_SESSION['login'] == 1):

				header("location:$jumpUrl");
				exit;

			endif;

			$this->view->display('login.tpl');
		
		}

		public function login(){

			$name = trim($_POST['name']);

			$psd = md5($_POST['passwd']);

			$sql = "select id from admin where name= '$name' and passwd = '$psd'";

			$res = $this->db->query($sql);

			if(count($res) > 0):
				$_SESSION['login'] = 1;
				echo 'success';
			else:
				echo 'error';
			endif;


		}

		public function logout(){

			session_destroy();

			echo 'success';

		}

		public function revise(){

			$psd = md5(urldecode($_GET['psd']));

			$this->db->execute("update admin set passwd = '$psd' where id = 1");

			session_destroy();

			echo "success";

		}

	}

	return new login;

?>