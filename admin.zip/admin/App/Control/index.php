<?php
	
	class index extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){

			$res = $this->db->query('select passwd from admin where id = 1');

			if($res[0]['passwd'] != md5('admin')):

				$this->view->assign('hide',true);

			endif;

			$this->view->display('index.tpl');
		
		}

	}

	return new index;

?>