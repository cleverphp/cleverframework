<?php
	
	class category extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){

			$cat = $this->db->query("select * from cat where parent = 0");

			$one = array();

			foreach($cat as $k=>$v){
				array_push($one,$v);
				$tmp = $this->db->query("select * from cat where parent = '{$v['id']}'");
				$cat[$k]['second'] = $tmp;
			}

			$this->view->assign('one',$one);

			$this->view->assign('cat',$cat);

			$this->view->display('category.tpl');
		
		}

		public function addOne(){

			$name = $this->trick_str($_POST['name']);

			$res = $this->db->query("insert into cat(name) values('{$name}')");

			if($res){
				echo 'ok';
			}

		}

		public function addTwo(){

			$name = $this->trick_str($_POST['name']);

			$id = $_POST['id'];

			$res = $this->db->query("insert into cat(name,parent) values('{$name}','{$id}')");

			if($res){
				echo 'ok';
			}

		}

		public function delete(){

			$this->db->query("delete from cat where id = '{$_POST['id']}'");
		}

		private function trick_str($str){

			$str = str_replace('\'','\\\'',$str);

			return $str;
		}

	}

	return new category;

?>