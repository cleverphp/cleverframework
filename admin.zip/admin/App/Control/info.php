<?php
	
	class info extends App{
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function index(){

			$data = $this->db->query("select ctn from info where id = 1");

			$str = '';

			if(!is_null($data[0]['ctn'])):

				$str = base64_decode($data[0]['ctn']);

			endif;

			$this->view->assign('str',htmlspecialchars($str));

			$this->view->display('info.tpl');
		
		}

		public function save(){

			$ctn = urldecode($_POST['ctn']);

			$ctn = base64_encode($ctn);

			$this->db->query("update info set ctn = '$ctn' where id = 1");

			echo 'ok';

		}

	}

	return new info;

?>