<?php
	
	class product extends App{

		const PAGE_SIZE = 2;
		
		//you must use this func to ini data
		public function __construct(){
			
			parent::__construct();
		
		}

		public function upload(){

			$cat = $this->db->query("select * from cat where parent = 0");

			foreach($cat as $k=>$v){

				$cat[$k]['second'] = $this->db->query("select * from cat where parent = '{$v['id']}'");

			}

			$this->view->assign('cat',$cat);

			$this->view->display('product_upload.tpl');
		
		}

		public function getSecondCat(){

			$one = $_POST['one'];

			$res = $this->db->query("select * from cat where parent = '{$one}'");

			echo json_encode($res);

		}

		public function ajax_upload(){

			$files = array();

			for($i=0;$i<=2;$i++){

				if(isset($_FILES['file'.$i])){
					array_push($files,$_FILES['file'.$i]);
				}
			}

			foreach($files as $v){

				if(!in_array($v['type'],array('image/jpeg','image/png','image/gif')) || $v['size'] > 4*1024*1024):
					exit('error');
				endif;

			}

			$name = time();

			$url = [];

			foreach($files as $k=>$v){

				$tmp  = $name.'_'.$k;

				$ext = strrchr($v['name'],'.');

				$tmp .= $ext;

				move_uploaded_file($v['tmp_name'],$_SERVER['DOCUMENT_ROOT'].DS.'data'.DS.'images'.DS.$tmp);

				$url[] = '/data/images/'.$tmp;

			}

			echo json_encode($url);

		}

		public function save_upload(){

			$images = serialize(explode(',',$_POST['images']));

			$details = base64_encode($_POST['detail']);

			$title = $this->trick_str($_POST['title']);

			$model = $this->trick_str($_POST['model']);

			$one = intval($_POST['catOne']);

			$two = intval($_POST['catTwo']);

			$short_detail = $this->trick_str($_POST['short_detail']);

			$sql = "insert into goods(name,type,short_desc,images,details,one,two) values('{$title}','{$model}','{$short_detail}','{$images}','{$details}','{$one}','{$two}')";

			$this->db->execute($sql);

			echo "success";

		}

		public function save_edit_upload(){

			$images = serialize(explode(',',$_POST['images']));

			$details = base64_encode($_POST['detail']);

			$title = $this->trick_str($_POST['title']);

			$model = $this->trick_str($_POST['model']);

			$short_detail = $this->trick_str($_POST['short_detail']);

			$id = $_GET['id'];

			$one = intval($_POST['catOne']);

			$two = intval($_POST['catTwo']);

			$sql = "update goods set 
			name = '$title',type = '$model',short_desc = '$short_detail',images = '$images',details = '$details',one = '$one',two = '$two' 
			where id = '$id'";

			$this->db->execute($sql);

			echo "success";

		}

		public function edit(){


			$this->view->display('product_edit.tpl');
		
		}

		public function get_p_num(){

			$res = $this->db->query("select count(id) as num from goods");

			echo ceil($res[0]['num']/self::PAGE_SIZE);

		}

		public function get_p_num_by_state(){

			$state = trim($_GET['state']);

			switch($state):
				case 'p_offline':
					$state = 0;
					break;
				case 'p_online':
					$state = 1;
					break;
				default:
					$state = 1;
					break;
			endswitch;

			$res = $this->db->query("select count(id) as num from goods where online = '$state'");

			echo ceil($res[0]['num']/self::PAGE_SIZE);

		}

		public function get_p_num_by_search(){

			$word = $this->trick_str(trim($_GET['word']));

			$res = $this->db->query("select count(id) as num from goods where type = '$word' or name like '%$word%'");

			echo ceil($res[0]['num']/self::PAGE_SIZE);

		}

		public function get_p_data(){

			$page = $_GET['page'];

			$size = self::PAGE_SIZE;

			$start = ($page-1)*$size;

			$sql = "select id,name,type,images,online from goods limit $start,$size";

			$res = $this->db->query($sql);

			foreach($res as $k=>$v){

				$res[$k]['images'] = unserialize($v['images'])[0];
				$res[$k]['online'] = $v['online'] == 1 ? 'Online' : 'Offline';

			}

			echo json_encode($res);

		}

		public function get_p_data_by_state(){

			$state = trim($_GET['state']);

			switch($state):
				case 'p_offline':
					$state = 0;
					break;
				case 'p_online':
					$state = 1;
					break;
				default:
					$state = 1;
					break;
			endswitch;

			$page = $_GET['page'];

			$size = self::PAGE_SIZE;

			$start = ($page-1)*$size;

			$sql = "select id,name,type,images,online from goods where online = '$state' limit $start,$size";

			$res = $this->db->query($sql);

			foreach($res as $k=>$v){

				$res[$k]['images'] = unserialize($v['images'])[0];
				$res[$k]['online'] = $v['online'] == 1 ? 'Online' : 'Offline';

			}

			echo json_encode($res);

		}

		public function get_p_data_by_search(){

			$word = $this->trick_str(trim($_GET['word']));

			$page = $_GET['page'];

			$size = self::PAGE_SIZE;

			$start = ($page-1)*$size;

			$sql = "select id,name,type,images,online from goods where type = '$word' or name like '%$word%' limit $start,$size";

			$res = $this->db->query($sql);

			foreach($res as $k=>$v){

				$res[$k]['images'] = unserialize($v['images'])[0];
				$res[$k]['online'] = $v['online'] == 1 ? 'Online' : 'Offline';

			}

			echo json_encode($res);

		}

		public function makeItOff(){

			$id = intval($_GET['id']);

			$res = $this->db->execute("update goods set online = 0 where id = '$id'");

			if($res){

				echo "ok";

			}else{

				echo "err";

			}


		}

		public function makeItOn(){

			$id = intval($_GET['id']);

			$res = $this->db->execute("update goods set online = 1 where id = '$id'");

			if($res){

				echo "ok";

			}else{

				echo "err";
				
			}


		}

		public function delIt(){

			$id = intval($_GET['id']);

			$res = $this->db->execute("delete from goods where id = '$id'");

			if($res){

				echo "ok";

			}else{

				echo "err";
				
			}

		}

		public function editOnline(){

			$id = intval($_GET['id']);

			$res = $this->db->query("select * from goods where id = '$id'");

			$res = $res[0];

			$res['name'] = $this->another_str($res['name']);

			$res['type'] = $this->another_str($res['type']);

			$res['images'] = unserialize($res['images']);

			$res['details'] = htmlspecialchars(urldecode(base64_decode($res['details'])));

			$this->view->assign('res',$res);

			$cat = $this->db->query("select * from cat where parent = 0");

			foreach($cat as $k=>$v){

				if($v['id'] == $res['one']){
					$this->view->assign('idOne',$k);
					$cat[$k]['second'] = $this->db->query("select * from cat where parent = '{$v['id']}'");
				}
				
			}

			$this->view->assign('cat',$cat);

			$this->view->display('editOnline.tpl');

		}

		private function another_str($str){

			$str = str_replace('"','\'',$str);

			return $str;

		}


		private function trick_str($str){

			$str = str_replace('\'','\\\'',$str);

			return $str;
		}

	}

	return new product;

?>