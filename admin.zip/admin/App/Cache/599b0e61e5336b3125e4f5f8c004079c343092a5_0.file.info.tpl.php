<?php
/* Smarty version 3.1.30, created on 2016-09-24 21:27:22
  from "D:\WWW\admin\App\View\info.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57e67f3ac4a897_06161411',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '599b0e61e5336b3125e4f5f8c004079c343092a5' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\info.tpl',
      1 => 1474723640,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57e67f3ac4a897_06161411 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/css/kindeditor.css" />
<?php echo '<script'; ?>
 charset="utf-8" src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/kindeditor-min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 charset="utf-8" src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/en.js"><?php echo '</script'; ?>
>

   <div class="row" style="min-height:800px;">

   		<p class="text-info">编辑企业介绍:</p>

   		<textarea class="form-control" rows="20" name="content"><?php echo $_smarty_tpl->tpl_vars['str']->value;?>
</textarea>

   		<button class="btn btn-primary" onclick="saveCtn();">保存</button>
   </div>

   



	<?php echo '<script'; ?>
>
			var editor;
			KindEditor.options.filterMode = false;
			KindEditor.options.langType = 'en';
			
			KindEditor.ready(function(K) {
				editor = K.create('textarea[name="content"]', {
					allowFileManager : true
				});
			});

			function saveCtn(){

				 var ctn = encodeURIComponent(editor.html());

				 $.ajax({

				 	url : 'index.php?c=info&a=save',
				 	type : 'post',
				 	data : {'ctn':ctn},
				 	success : function(data){

				 		alert('保存成功');

				 	}

				 });

			}

	<?php echo '</script'; ?>
>


<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
