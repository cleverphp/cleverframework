<?php
/* Smarty version 3.1.30, created on 2016-10-03 20:43:20
  from "D:\WWW\admin\App\View\web.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57f25268f3e2f7_72661092',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ff9d150220791881fa75755752615694aea94aae' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\web.tpl',
      1 => 1475498597,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57f25268f3e2f7_72661092 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


	<div class="row" style="min-height:800px;">

		<p>网站标题</p>
		<input class="form-control" type="text" name="site-title" value="<?php if (isset($_smarty_tpl->tpl_vars['web']->value['title'])) {
echo $_smarty_tpl->tpl_vars['web']->value['title'];
}?>" />
		<br />
		<button class="btn btn-primary" onclick="reviseTitle();">确认</button>

		<p>企业名称,logo象征</p>
		<input class="form-control" type="text" name="site-corporate" value="<?php if (isset($_smarty_tpl->tpl_vars['web']->value['corporate'])) {
echo $_smarty_tpl->tpl_vars['web']->value['corporate'];
}?>" />
		<br />
		<button class="btn btn-primary" onclick="reviseCorporate();">确认</button>

		<p>网站ico（logo,网站标签将会显示这个图片）最佳尺寸32*32,ico格式</p>
		<input class="form-control" type="file" name="ico" /><br />
		<button class="btn btn-primary" onclick="uploadIco();">上传或替换</button>

		<p style="margin-top:10px;">关键词(英文逗号分隔keyword1,keyword2)</p>
		<input class="form-control" type="text" name="site-keyword" value="<?php if (isset($_smarty_tpl->tpl_vars['web']->value['keyword'])) {
echo $_smarty_tpl->tpl_vars['web']->value['keyword'];
}?>" />
		<br />
		<button class="btn btn-primary" onclick="reviseKeyword();">确认</button>
		<p style="margin-top:10px;">描述</p>
		<input class="form-control" type="text" name="site-desc" value="<?php if (isset($_smarty_tpl->tpl_vars['web']->value['desc'])) {
echo $_smarty_tpl->tpl_vars['web']->value['desc'];
}?>" />
		<br />
		<button class="btn btn-primary" onclick="reviseDesc();">确认</button>

	</div>

	

		<?php echo '<script'; ?>
>

			function uploadIco(){

				var file = document.querySelector('input[name=ico]').files;

				if(file.length == 0){
					alert('请先选择文件');
				}else{

					var data = new FormData();

					data.append('ico',file[0]);

					$.ajax({

						url : 'index.php?c=web&a=uploadIco',
						type : 'post',
						data : data,
						processData : false,
						contentType : false,
						success : function(data){

							if(data == 'err'){

								alert('请上传ico格式的文件或者保证尺寸不超过100KB');

							}else{

								alert('上传或修改成功!');

							}

						}

					});


				}

			}

			function reviseTitle(){

				var a = new revise('title');

				a.act();

			}

			function reviseCorporate(){

				var a = new revise('corporate');
				a.act();
			}

			function reviseKeyword(){

				var a = new revise('keyword');

				a.act();
				
			}

			function reviseDesc(){

				var a = new revise('desc');

				a.act();
				
			}

			function revise(name){

				this.name = name;

				this.item = $('input[name=site-'+this.name+']');

				this.act = function(){

					var val = this.item.val();

					var obj = this.item;

					$.ajax('index.php?c=web&a=update&item='+this.name+'&val='+val).done().always(function(data){

						if(data == 'success'){

							alert('修改成功！');
						}

					});

				}

			}

		<?php echo '</script'; ?>
>

	
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
