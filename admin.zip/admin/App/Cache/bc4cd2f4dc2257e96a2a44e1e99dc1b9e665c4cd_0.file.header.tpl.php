<?php
/* Smarty version 3.1.30, created on 2016-10-04 15:58:59
  from "D:\WWW\admin\App\View\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57f36143034215_00507424',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bc4cd2f4dc2257e96a2a44e1e99dc1b9e665c4cd' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\header.tpl',
      1 => 1475567747,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57f36143034215_00507424 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="robots" content="noindex,nofollow" />
    <meta name="author" content="">

    <title>Admin Dashboard</title>

    <link rel="shortcut icon" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/images/logo.ico">

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/css/sb-admin.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/css/plugins/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- jQuery -->
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/jquery.js"><?php echo '</script'; ?>
>

    <!-- Bootstrap Core JavaScript -->
    <?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/bootstrap.min.js"><?php echo '</script'; ?>
>


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"><?php echo '</script'; ?>
>
        <?php echo '<script'; ?>
 src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"><?php echo '</script'; ?>
>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <a class="navbar-brand" href="javascript:void(0);">Admin Dashboard</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li>
                    <a href="javascript:logout();"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                </li>
            </ul>
            
                <?php echo '<script'; ?>
>
                    function logout(){

                        $.ajax('index.php?c=login&a=logout').done().always(function(data){

                            if(data.replace(/\s+/,'') == 'success'){

                                window.location.reload();
                            }

                        });
                    }
                <?php echo '</script'; ?>
>
            
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li class="active">
                        <a href="index.php"><i class="fa fa-fw fa-dashboard"></i>欢迎</a>
                    </li>
                    <li class="active">
                        <a href="index.php?c=setting"><i class="fa fa-fw fa-dashboard"></i>设置</a>
                    </li>
                    <li class="active">
                        <a href="index.php?c=category"><i class="fa fa-fw fa-dashboard"></i>分类管理</a>
                    </li>
                    <li class="active">
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-arrows-v"></i> 产品 <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="index.php?c=product&a=upload">产品上传</a>
                            </li>
                            <li>
                                <a href="index.php?c=product&a=edit">产品管理</a>
                            </li>
                        </ul>
                    </li>
                    <li class="active">
                        <a href="index.php?c=web"><i class="fa fa-fw fa-dashboard"></i>网站</a>
                    </li>
                    <li class="active">
                        <a href="index.php?c=web_footer"><i class="fa fa-fw fa-dashboard"></i>网站底部联系方式等等</a>
                    </li>
                    <li class="active">
                        <a href="index.php?c=lunbo"><i class="fa fa-fw fa-dashboard"></i>首页轮播图设置</a>
                    </li>
                    <li class="active">
                        <a href="index.php?c=info"><i class="fa fa-fw fa-dashboard"></i>企业介绍</a>
                    </li>
                    <li class="active">
                        <a href="index.php?c=contact"><i class="fa fa-fw fa-dashboard"></i>联系信息</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

         <div id="page-wrapper">

            <div class="container-fluid"><?php }
}
