<?php
/* Smarty version 3.1.30, created on 2016-10-04 16:26:14
  from "D:\WWW\admin\App\View\lunbo.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57f367a6adb606_63154945',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a2ba5d2ae433d5e15066637aafb480beed7754c0' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\lunbo.tpl',
      1 => 1475569572,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57f367a6adb606_63154945 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	

   <div class="row" style="min-height:800px;">

   
   		<p style="margin-top:10px;" class="text-info">轮播图片(最多10张，建议尺寸900*400):</p>
   		<ul class="list-group" id="up-list-images">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['maxImage']->value, 'num');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['num']->value) {
?>
          <?php if (isset($_smarty_tpl->tpl_vars['lunbo']->value[$_smarty_tpl->tpl_vars['num']->value])) {?>
     			<li class="list-group-item" style="float:left;border:solid 1px black;">
     				<img class="img-responsive" src="<?php echo $_smarty_tpl->tpl_vars['lunbo']->value[$_smarty_tpl->tpl_vars['num']->value];?>
" />
     			</li>
          <?php } else { ?>
            <li class="list-group-item" style="float:left;border:solid 1px black;">
              <img class="img-responsive" src="/admin/App/Public/images/add.jpg" />
            </li>
          <?php }?>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

   		</ul>
   		<p style="clear:both;"></p>
         <input id="my-image-up" style="display:none;" type="file" name="up-images" multiple />
         <p id="ajax-wait-icon" style="display:none;color:red;">正在上传...</p>
   		<p><button class="btn btn-primary" onclick="upload_start()">上传</button></p>

      <p>确认修改请点击保存按钮</p>
      <button class="btn btn-primary" onclick="saveCtn();">保存</button>
   	
   </div>



	<?php echo '<script'; ?>
>

         var images_url_arr = [];

         function show_waiting(){
            $('#ajax-wait-icon').show();
         }

         function close_waiting(){
            $('#ajax-wait-icon').hide();
         }

         function upload_start(){

            images_url_arr = [];

            document.getElementById('my-image-up').files = null;

            $('input[name=up-images]').val('');

            var list = $('#up-list-images').find('li');

            for(var i=0;i<list.length;i++){
                $(list[i]).find('img').attr('src','/admin/App/Public/images/add.jpg');
            }

            $('input[name=up-images]').trigger('click');

            $('input[name=up-images]').on('change',function(){

                 var files = document.getElementById('my-image-up').files;

                 var data = new FormData();

                 var key;

                 for(var i=0;i<files.length;i++){

                     key = 'file'+i;
                     data.append(key,files[i]);

                 }

                 $.ajax({

                     url : 'index.php?c=lunbo&a=ajax_upload',
                     type : 'post',
                     data : data,
                     beforeSend : show_waiting,
                     complete : close_waiting,
                     processData : false,
                     contentType : false,
                     success :function(data){

                        var list = $('#up-list-images').find('li');

                        if(data != 'error'){
                            data = JSON.parse(data);
                            for(var i in data){
                              images_url_arr.push(data[i]);
                              $(list[i]).find('img').attr('src',data[i]);
                            }
                        }else{
                          alert("上传文件不能超过4M");
                        }

                     }


                 });

            });

			 }

        function saveCtn(){

         var images = String(images_url_arr);

         $.ajax({

            url : 'index.php?c=lunbo&a=save_upload',
            type : 'post',
            data : {'images':images},
            success : function(data){

              alert('更新成功');
              window.location.reload();

            }

         });

       }

	<?php echo '</script'; ?>
>


<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
