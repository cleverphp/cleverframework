<?php
/* Smarty version 3.1.30, created on 2016-09-24 15:04:23
  from "D:\WWW\admin\App\View\setting.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57e62577d47379_34322205',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf4ea4c4ac8f0bfb41f04b7f0ac79e12779899be' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\setting.tpl',
      1 => 1474700662,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57e62577d47379_34322205 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	
	<div class="row" style="height:800px;">
		<p>设置新的密码:</p>
		<input class="form-control" type="password" name="passwd" placeholder="请输入新的密码" />
		<br />
		<input class="form-control" type="password" name="passwds" placeholder="请再次输入新的密码" />

		<br />
		<button class="btn btn-primary" onclick="confRevise();">确认修改</button>

	</div>



	<?php echo '<script'; ?>
>
		function confRevise(){

			var psd = $('input[name=passwd]').val();

			var psdc = $('input[name=passwds]').val();

			if(psd != psdc){

				alert('两次输入密码不一致!');
			}else{

				$.ajax('index.php?c=login&a=revise&psd='+encodeURIComponent(psd)).done().always(function(data){

						if(data == 'success'){

							alert('修改成功!请使用新的密码登录');
							window.location.reload();

						}

				});

			}

		}
	<?php echo '</script'; ?>
>



<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
