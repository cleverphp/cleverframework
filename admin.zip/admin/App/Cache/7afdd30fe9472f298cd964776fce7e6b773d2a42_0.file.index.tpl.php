<?php
/* Smarty version 3.1.30, created on 2016-09-24 14:40:57
  from "D:\WWW\admin\App\View\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57e61ff9c2d820_01723332',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7afdd30fe9472f298cd964776fce7e6b773d2a42' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\index.tpl',
      1 => 1474699254,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57e61ff9c2d820_01723332 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


    <div class="row" style="height:800px;background:url('/admin/App/Public/images/wel.jpg');">
        <p class="text-info">欢迎使用多终端统一管理后台，您在这里所做的任何更改都会反映到所有终端，包括公司详情，产品上下架，联系方式等等</p>

        <?php if (!$_smarty_tpl->tpl_vars['hide']->value) {?>
        <p class="text-warning" style="margin-top:20px;">为保证您的账号安全，请及时进行密码修改</p>

        <p class="text-danger" style="margin-top:20px;">密码修改在设置面板里</p>
        <?php }?>
    </div>
       


<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
