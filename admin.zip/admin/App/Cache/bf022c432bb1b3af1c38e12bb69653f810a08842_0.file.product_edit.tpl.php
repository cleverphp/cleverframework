<?php
/* Smarty version 3.1.30, created on 2016-10-02 17:51:55
  from "D:\WWW\admin\App\View\product_edit.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57f0d8bb463558_75717240',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf022c432bb1b3af1c38e12bb69653f810a08842' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\product_edit.tpl',
      1 => 1475401911,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57f0d8bb463558_75717240 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

	
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/angular.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/paginator.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/edit_product.js"><?php echo '</script'; ?>
>
	<link href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/css/product.css" rel="stylesheet" type="text/css" />

	
	<!---app start that not need smarty any more-->

	<div class="row" style="min-height:800px;" ng-app="index" ng-controller="index">

		<p class="text-info">产品管理</p>

		<h4 class="text-danger" style="font-size:12px;font-weight:bold;">请选择产品状态，默认显示上架的产品</h4>
		<select class="form-control" style="width:40%;" ng-model="p_state" ng-change="show_state()">
			<option value="p_online">上架的产品</option>
			<option value="p_offline">下架的产品</option>
		</select>
		<h4 class="text-danger" style="font-size:12px;font-weight:bold;">在此处输入产品型号或标题关键词进行搜索</h4>
		<p style="width:40%;">
			<input ng-model="search_txt" style="display:inline;" type="text" class="form-control" />
			<span ng-click="show_search_result()" style="display:inline;float:right;margin-top:-25px;margin-right:10px;cursor:pointer;" class="glyphicon glyphicon-search"></span>
		</p>

		<ul class="list-group">

			<li class="list-group-item li-title">

				<span>
					产品图片
				</span>
				<span>
					产品标题
				</span>
				<span>
					产品型号
				</span>
				<span>
					产品状态
				</span>
				<span>
					操作
				</span>

			</li>

		</ul>

		<ul class="list-group">

			<li class="list-group-item list-product" ng-repeat="(k,p) in products.item track by $index">

				<img ng-src="{{p.images}}" class="img-responsive" />
				<a href="#">
				<span class="text-desc-list">{{p.name}}</span>
				</a>
				<span class="model-desc-list">{{p.type}}</span>
				<span class="state-desc-list">{{p.online}}</span>
				<span ng-hide="p.online == 'Online'" ng-click="makeItOn(k,p.id)" class="offline-desc-list">上架</span>
				<span ng-hide="p.online == 'Offline'" ng-click="makeItOff(k,p.id)" class="offline-desc-list">下架</span>
				<span ng-click="editIt(k,p.id)" class="edit-desc-list">编辑</span>
				<span ng-click="delIt(k,p.id)" class="del-desc-list">删除</span>
				<p style="clear:both;"></p>

			</li>

		</ul>
		<p style="text-align:center;">

			<button class="btn btn-default" ng-disabled="!products.up" ng-click="goHome()">首页</button>
			<button class="btn btn-default" ng-disabled="!products.up" ng-click="goUp()">上一页</button>
			<button class="btn btn-default" ng-show="products.now > 2" ng-click="goPage(products.now-2)">{{products.now-2}}</button>
			<button class="btn btn-default" ng-show="products.now > 1" ng-click="goPage(products.now-1)">{{products.now-1}}</button>
			<button class="btn btn-primary">{{products.now}}</button>
			<button class="btn btn-default" ng-disabled="products.now+1 > products.total" ng-click="goPage(products.now+1)">{{products.now+1}}</button>
			<button class="btn btn-default" ng-disabled="products.now+2 > products.total" ng-click="goPage(products.now+2)">{{products.now+2}}</button>
			<button class="btn btn-default" ng-disabled="!products.down" ng-click="goDown()">下一页</button>
			<button class="btn btn-default" ng-disabled="!products.down" ng-click="goEnd()">末页</button>

		</p>


	</div>
    


<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
