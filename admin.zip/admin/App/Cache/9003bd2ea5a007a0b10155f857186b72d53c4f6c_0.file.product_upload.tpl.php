<?php
/* Smarty version 3.1.30, created on 2016-10-04 13:44:43
  from "D:\WWW\admin\App\View\product_upload.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57f341cb85f529_91915101',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9003bd2ea5a007a0b10155f857186b72d53c4f6c' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\product_upload.tpl',
      1 => 1475553693,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57f341cb85f529_91915101 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
	

<link rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/css/kindeditor.css" />
<?php echo '<script'; ?>
 charset="utf-8" src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/kindeditor-min.js"><?php echo '</script'; ?>
>
<?php echo '<script'; ?>
 charset="utf-8" src="<?php echo $_smarty_tpl->tpl_vars['assets']->value;?>
/js/en.js"><?php echo '</script'; ?>
>

   <div class="row" style="min-height:800px;">

   		<p class="text-info">产品标题:</p>
   		<input type="text" name="p-title" class="form-control" />

   		<p style="margin-top:10px;" class="text-info">产品型号:</p>
   		<input type="text" name="p-model" class="form-control" />
      <p style="margin-top:10px;" class="text-info">产品分类:</p>
      <select class="form-control" style="width:30%;float:left;" name="oneCat" onchange="showSecond()">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cat']->value, 'it');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['it']->value) {
?>
          <option value="<?php echo $_smarty_tpl->tpl_vars['it']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['it']->value['name'];?>
</option>
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

      </select>
      <select class="form-control" style="width:30%;float:left;" name="secondCat">
        <?php if (isset($_smarty_tpl->tpl_vars['cat']->value[0]['second'])) {?>
          <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cat']->value[0]['second'], 'sec');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['sec']->value) {
?>
            <option value="<?php echo $_smarty_tpl->tpl_vars['sec']->value['id'];?>
"><?php echo $_smarty_tpl->tpl_vars['sec']->value['name'];?>
</option>
          <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

        <?php }?>
      </select>

      <p style="clear:both;"></p>

   		<p style="margin-top:10px;" class="text-info">产品简短描述:</p>
   		<textarea style="resize:none;" cols="80" rows="8" id="short-desc"></textarea>

   		<p style="margin-top:10px;" class="text-info">产品图片:</p>
   		<ul class="list-group" id="up-list-images">
   			<li class="list-group-item" style="float:left;border:solid 1px black;">
   				<img class="img-responsive" src="/admin/App/Public/images/add.jpg" />
   				<span style="position:absolute;right:0px;top:0px;font-size:12px;color:white;background-color:gray;padding:5px;border-radius:5px;cursor:pointer;" onclick="setImageDefault($(this))">设为主图</span>
   			</li>
			<li class="list-group-item" style="float:left;border:solid 1px black;">
   				<img class="img-responsive" src="/admin/App/Public/images/add.jpg" />
   				<span style="position:absolute;right:0px;top:0px;font-size:12px;color:white;background-color:gray;padding:5px;border-radius:5px;cursor:pointer;" onclick="setImageDefault($(this))">设为主图</span>
   			</li>
			<li class="list-group-item" style="float:left;border:solid 1px black;">
   				<img class="img-responsive" src="/admin/App/Public/images/add.jpg" />
   				<span style="position:absolute;right:0px;top:0px;font-size:12px;color:white;background-color:gray;padding:5px;border-radius:5px;cursor:pointer;" onclick="setImageDefault($(this))">设为主图</span>
   			</li>
   		</ul>
   		<p style="clear:both;"></p>
         <input id="my-image-up" style="display:none;" type="file" name="up-images" multiple />
         <p id="ajax-wait-icon" style="display:none;color:red;">正在上传...</p>
   		<p><button class="btn btn-primary" onclick="upload_start()">上传</button></p>

   		<p style="margin-top:10px;" class="text-info">产品详情:</p>

   		<textarea class="form-control" rows="20" name="content"></textarea>

   		<button class="btn btn-primary" onclick="saveCtn();">保存</button>
   </div>



	<?php echo '<script'; ?>
>

         var images_url_arr = [];

         function show_waiting(){
            $('#ajax-wait-icon').show();
         }

         function close_waiting(){
            $('#ajax-wait-icon').hide();
         }

         function upload_start(){

            images_url_arr = [];

            document.getElementById('my-image-up').files = null;

            $('input[name=up-images]').val('');

            var list = $('#up-list-images').find('li');

            for(var i=0;i<list.length;i++){
                $(list[i]).find('img').attr('src','/admin/App/Public/images/add.jpg');
            }

            $('input[name=up-images]').trigger('click');

            $('input[name=up-images]').on('change',function(){

                 var files = document.getElementById('my-image-up').files;

                 var data = new FormData();

                 var key;

                 for(var i=0;i<files.length;i++){

                     key = 'file'+i;
                     data.append(key,files[i]);

                 }

                 $.ajax({

                     url : 'index.php?c=product&a=ajax_upload',
                     type : 'post',
                     data : data,
                     beforeSend : show_waiting,
                     complete : close_waiting,
                     processData : false,
                     contentType : false,
                     success :function(data){

                        var list = $('#up-list-images').find('li');

                        if(data != 'error'){
                            data = JSON.parse(data);
                            for(var i in data){
                              images_url_arr.push(data[i]);
                              $(list[i]).find('img').attr('src',data[i]);
                            }
                        }else{
                          alert("上传文件不能超过4M");
                        }

                     }


                 });

                 

            });


         }

         function setImageDefault(obj){

             var src = obj.siblings('img').attr('src');

             if(src == '/admin/App/Public/images/add.jpg'){

                  alert("请先上传");

             }else{

                var tmp_arr = [];

                for(var i=0;i<images_url_arr.length;i++){

                    if(images_url_arr[i] != src){
                        tmp_arr.push(images_url_arr[i]);
                    }else{
                        tmp_arr.unshift(src);
                    }

                }

                images_url_arr = tmp_arr;

                obj.parent().siblings('li').find('span').css('backgroundColor','gray');

                obj.css('backgroundColor','green');

             }

         }


			var editor;
			KindEditor.options.filterMode = false;
			KindEditor.options.langType = 'en';
			
			KindEditor.ready(function(K) {
				editor = K.create('textarea[name="content"]', {
					allowFileManager : true
				});
			});

      function showSecond(){

        var one = $('select[name=oneCat]').val();

        $.post('index.php?c=product&a=getSecondCat',{one:one}).success(function(data){

            var str = '';
            data = JSON.parse(data);
            for(var i in data){
                str += '<option value="'+data[i].id+'">'+data[i].name+'</option>';
            }

            $('select[name=secondCat]').html(str);

        });

      }

			function saveCtn(){

				 var ctn = encodeURIComponent(editor.html());

         var title = $('input[name=p-title]').val();

         var model = $('input[name=p-model]').val();

         var short_detail = $('#short-desc').val();

         var oneCat = $('select[name=oneCat]').val();

         var secCat = $('select[name=secondCat]').val();

         if(oneCat == null){

            alert("请先在分类管理添加新的分类");
            return false;

         }

         if(secCat == null){

            secCat = 0;

         }

         var images = String(images_url_arr);

				 $.ajax({

				 	url : 'index.php?c=product&a=save_upload',
				 	type : 'post',
				 	data : {'detail':ctn,'title':title,'model':model,'short_detail':short_detail,'images':images,'catOne':oneCat,'catTwo':secCat},
				 	success : function(data){

				 		alert('发布成功');
            window.location = "index.php?c=product&a=edit";

				 	}

				 });

			}

	<?php echo '</script'; ?>
>


<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
