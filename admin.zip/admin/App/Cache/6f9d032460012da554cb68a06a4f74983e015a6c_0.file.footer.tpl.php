<?php
/* Smarty version 3.1.30, created on 2016-10-02 22:02:27
  from "D:\WWW\admin\App\View\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57f113732a51f0_33600161',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6f9d032460012da554cb68a06a4f74983e015a6c' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\footer.tpl',
      1 => 1475416941,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_57f113732a51f0_33600161 (Smarty_Internal_Template $_smarty_tpl) {
?>


    
        </div>
        <!-- /#page-wrapper -->

    </div>

</body>

</html>
<?php }
}
