<?php
/* Smarty version 3.1.30, created on 2016-09-24 13:35:01
  from "D:\WWW\admin\App\View\login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57e61085006767_14098046',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b3abbd1b27fd5311ec18a82071771a13d7fc31ae' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\login.tpl',
      1 => 1474695167,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:login_header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57e61085006767_14098046 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:login_header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


 <div class="container" style="width:600px;margin-top:100px;">
	<form name="login" role="form" action="index.php?c=login&a=login" method="post">
	  <div class="form-group">
	    <label for="name" style="color:white;">用户名</label>
	    <input type="text" style="color:black;" class="form-control" id="name" name="name" placeholder="请输入用户名" />
	  </div>
	  <div class="form-group">
	    <label for="passwd" style="color:white;">密码</label>
	    <input type="password" style="color:black;" class="form-control" name="passwd" id="passwd" />
	  </div>
	  <button type="submit" class="btn btn-default" style="color:black;">登录</button>
	</form>
  </div>

  

  		<?php echo '<script'; ?>
>

  				$('form[name=login]').submit(function(e){

  					var method = $(this).attr('method');

  					var action = $(this).attr('action');

  					var data = $(this).serialize();

  					$.ajax({

  						url : action,
  						type : method,
  						data : data,
  						success : function(data){

  							if(data != 'success'){

  								alert('用户名或密码错误');

  							}else{

  								window.location = '/admin/index.php';
  							}

  						}

  					});

  					e.preventDefault();

  				})

  		<?php echo '</script'; ?>
>

  
<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
