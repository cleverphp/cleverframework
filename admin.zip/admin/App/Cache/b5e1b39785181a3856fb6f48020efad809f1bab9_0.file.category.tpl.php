<?php
/* Smarty version 3.1.30, created on 2016-10-04 11:54:31
  from "D:\WWW\admin\App\View\category.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_57f327f75e5cb9_35852306',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b5e1b39785181a3856fb6f48020efad809f1bab9' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\category.tpl',
      1 => 1475553269,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57f327f75e5cb9_35852306 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


    <div class="row" style="min-height:800px;">

    	<h4>一级分类</h4>
    	<ul class="list-group">
    		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['one']->value, 'it');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['it']->value) {
?>
    		<li class="list-group-item">
    			<span><?php echo $_smarty_tpl->tpl_vars['it']->value['name'];?>
</span>
    			<a href="javascript:deleteCat('<?php echo $_smarty_tpl->tpl_vars['it']->value['id'];?>
');"><span style="float:right;">删除</span></a>
    		</li>
    		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

    	</ul>
    	<input type="text" name="add-one" class="form-control" />
    	<button class="btn btn-default" onclick="addOneCat()">添加</button>

    	<p style="border-bottom:dashed 2px black;margin:10px auto;"></p>

    	<h4>二级分类</h4>
    	<ul class="list-group">
    		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['cat']->value, 'it');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['it']->value) {
?>
    		<li class="list-group-item">
    			<p><?php echo $_smarty_tpl->tpl_vars['it']->value['name'];?>
</p>
    			<ul class="list-group">
    				<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['it']->value['second'], 'sec');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['sec']->value) {
?>
		    		<li class="list-group-item">
		    			<span><?php echo $_smarty_tpl->tpl_vars['sec']->value['name'];?>
</span>
		    			<a href="javascript:deleteCat('<?php echo $_smarty_tpl->tpl_vars['sec']->value['id'];?>
');"><span style="float:right">删除</span></a>
		    		</li>
		    		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

		    	</ul>
		    	<input type="text" name="add-two-<?php echo $_smarty_tpl->tpl_vars['it']->value['id'];?>
" class="form-control" />
		    	<button class="btn btn-default" onclick="addTwoCat('<?php echo $_smarty_tpl->tpl_vars['it']->value['id'];?>
')">添加</button>
    		</li>
    		<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

    	</ul>
    	
    </div>

    

    	<?php echo '<script'; ?>
>

    		function addOneCat(){

    			var name = $('input[name=add-one]').val();

    			if(name.replace(/\s+/,'') == ''){
    				alert('请输入添加分类的名称');
    				return false;
    			}

    			$.post('index.php?c=category&a=addOne',{name:name}).success(function(data){
    				
    					window.location.reload();
    			});

    		}

    		function addTwoCat(id){

    			var name = $('input[name=add-two-'+id+']').val();

    			if(name.replace(/\s+/,'') == ''){
    				alert('请输入添加分类的名称');
    				return false;
    			}

    			$.post('index.php?c=category&a=addTwo',{name:name,id:id}).success(function(data){
    				
    					window.location.reload();
    			});

    		}

    		function deleteCat(id){

    			$.post('index.php?c=category&a=delete',{id:id}).success(function(data){
    				
    					window.location.reload();
    			});

    		}

    	<?php echo '</script'; ?>
>

    
       

<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
