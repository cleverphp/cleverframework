<?php
/* Smarty version 3.1.30, created on 2016-10-16 22:29:51
  from "D:\WWW\admin\App\View\contact.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_58038edf767674_71717506',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'fe96ac320dc39a2c53051c308c46206160929a90' => 
    array (
      0 => 'D:\\WWW\\admin\\App\\View\\contact.tpl',
      1 => 1476628185,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_58038edf767674_71717506 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_subTemplateRender("file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


    <div class="row" style="min-height:800px;">

    	<p style="font-weight:bold">接收询盘的邮箱地址</p>
    	<input class="form-control" name="site-receiver" value="<?php echo $_smarty_tpl->tpl_vars['see']->value;?>
" />
    	<br />
    	<button class="btn btn-primary" onclick="reviseDesc()">提交</button>
    	
    </div>
    
    

    	<?php echo '<script'; ?>
>

	    	    function reviseDesc(){

					var a = new revise('receiver');

					a.act();
					
				}

				function revise(name){

					this.name = name;

					this.item = $('input[name=site-'+this.name+']');

					this.act = function(){

						var val = this.item.val();

						var obj = this.item;

						$.ajax('index.php?c=web&a=update&item='+this.name+'&val='+val).done().always(function(data){

							if(data == 'success'){

								alert('更新成功！');
							}

						});

					}

				}

		<?php echo '</script'; ?>
>

    


<?php $_smarty_tpl->_subTemplateRender("file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
