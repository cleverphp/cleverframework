var app = angular.module('index',['paginator']);

app.controller('index',['$scope','$http','page',function($scope,$http,page){

	$scope.p_state = 'p_online';

	$scope.show_state = function(){

		var state = $scope.p_state;

		page.ini('index.php?c=product&a=get_p_num_by_state&state='+state,'index.php?c=product&a=get_p_data_by_state&state='+state);

	}

	$scope.show_search_result = function(){

		var word = $scope.search_txt;

		page.ini('index.php?c=product&a=get_p_num_by_search&word='+word,'index.php?c=product&a=get_p_data_by_search&word='+word);

	}

	$scope.makeItOff = function(k,id){

		$http.get('index.php?c=product&a=makeItOff&id='+id).success(function(data){

			if(data == 'ok'){

				$scope.products.item[k]['online'] = 'Offline';
			}

		});

	}

	$scope.makeItOn = function(k,id){

		$http.get('index.php?c=product&a=makeItOn&id='+id).success(function(data){

			if(data == 'ok'){

				$scope.products.item[k]['online'] = 'Online';
			}

		});

	}

	$scope.delIt = function(k,id){

		$http.get('index.php?c=product&a=delIt&id='+id).success(function(data){

			if(data == 'ok'){

				$scope.products.item.splice(k,1);
			}

		});

	}

	$scope.editIt = function(k,id){

		window.location = 'index.php?c=product&a=editOnline&id='+id;
	}

	$scope.products = [];

	page.ini('index.php?c=product&a=get_p_num','index.php?c=product&a=get_p_data');

	$scope.goHome = function(){

		page.home();
		page.show();

	}

	$scope.goUp = function(){

		page.up();
		page.show();

	}

	$scope.goPage = function(num){

		page.jump(num);
		page.show();

	}

	$scope.goDown = function(){

		page.down();
		page.show();

	}

	$scope.goEnd = function(){

		page.end();
		page.show();

	}




}]);